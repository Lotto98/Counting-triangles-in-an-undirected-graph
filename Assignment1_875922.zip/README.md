# Counting triangles in an undirected graph

Assignment 1 for LEARNING WITH MASSIVE DATA course